# Dark-Fb
![Python|2.7](https://img.shields.io/badge/Python-2.7-blue.svg)
<br><h1><a href="https://wa.me/6282211661007?text=Saya%20Mao%20Beli%20Linse%20Dark%20Fb%20Harga%2010k">Contact WhatsApp </a></h1><br><h3> Facebook  Hacking Tool</h3><br>
<img src="https://github.com/wareares/ss/blob/master/Screenshot_20191017-001230_Termux.jpg"/>
<br><br>
<h3>Installing</h3><br>


$ pkg install git<br>
$ pkg install curl<br>
$ git clone https://github.com/Mr-XsZ/Dark-Fb<br>
$ cd Dark-Fb<br>
$ bash install.sh<br><br>


<h1>Menu Tools</h1><br>
<img src="https://github.com/wareares/ss/blob/master/Screenshot_20191022-093414_Termux-picsay.jpg"/>
<br><h1>Account Checker</h1><br>
<img src="https://github.com/Mr-XsZ/Dark-Fb/blob/master/Raw/Screenshot.png"/>
<h1><a href ="https://www.youtube.com/channel/UCLU9H65QrIC6u2UetU6476w">YouTube Tutorial</a></h1>
<a href ="https://mbasic.facebook.com/2angga315">ask me on facebook</a>
 
